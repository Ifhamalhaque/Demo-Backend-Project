const pool = require('../../config/database');

module.exports = {
    /* Creating a method for recieving data from controller and calling back */
    create: (data, callBack) => {
        pool.query(
            "insert into registration(FirstName,LastName,Email,Address,Password,Role['admin','user']) values(?,?,?,?,?,?)", [
                data.FirstName,
                data.LastName,
                data.Email,
                data.Address,
                data.Password,
                data.Role['admin', 'user']
            ],
            (error, results, fields) => {
                if (error) {
                    callBack(error);
                }
                return callBack(null, results);
            }
        );
    },
    /* Getting user email */
    getUserByUserEmail: (email, callBack) => {
        pool.query(
            `select * from registration where email = ?`, [email],
            (error, results, fields) => {
                if (error) {
                    callBack(error);
                }
                return callBack(null, results[0]);
            }
        );
    },
    getUserByUserId: (id, callBack) => {
        pool.query(
            `select id,firstName,lastName,email,address,password,role from registration where id = ?`, [id],
            (error, results, fields) => {
                if (error) {
                    callBack(error);
                }
                return callBack(null, results[0]);
            }
        );
    },
    getUsers: callBack => {
        pool.query(
            `select id,firstName,lastName,email,address,password,role from registration`, [],
            (error, results, fields) => {
                if (error) {
                    callBack(error);
                }
                return callBack(null, results);
            }
        );
    },
    /* Updating the user resgistration*/
    updateUser: (data, callBack) => {
        pool.query(
            `update registration set firstName=?, lastName=?, email=?, address=?, password=?, role=? where id = ?`, [
                data.FirstName,
                data.LastName,
                data.Email,
                data.Address,
                data.Password,
                data.Role['admin', 'user'],
                data.id


            ],
            (error, results, fields) => {
                if (error) {
                    callBack(error);
                }
                return callBack(null, results[0]);
            }
        );
    },
    /* Deleting the user*/
    deleteUser: (data, callBack) => {
        pool.query(
            `delete from registration where id = ?`, [data.id],
            (error, results, fields) => {
                if (error) {
                    callBack(error);
                }
                return callBack(null, results[0]);
            }
        );
    }
};